The following are the sub topics for Broken access control:

Insecure Direct Object References (IDOR)

Path Traversal Vulnerabilities

Missing Function Level Access Control

Forced Browsing

Privilege Escalation

Cross-Site Scripting (XSS)

Session Fixation

Cross-Site Request Forgery (CSRF)

Unvalidated Redirects and Forwards

Credential Stuffing

Broken Authentication and Session Management

Security Misconfiguration

Sensitive Data Exposure

Broken Access Control

Insufficient Logging and Monitoring
 
